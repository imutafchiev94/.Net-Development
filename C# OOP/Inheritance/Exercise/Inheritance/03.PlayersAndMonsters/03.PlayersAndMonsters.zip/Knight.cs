﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.PlayersAndMonsters
{
    public class Knight : Hero
    {
        public Knight(string username, int level) : base(username, level)
        {
        }
    }
}
