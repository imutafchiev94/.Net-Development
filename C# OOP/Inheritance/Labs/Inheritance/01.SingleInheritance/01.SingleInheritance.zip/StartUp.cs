﻿using System;

namespace Farm
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var dog = new Dog();


            dog.Bark();
            dog.Bark();
            dog.Eat();
            dog.Bark();
        }
    }
}
