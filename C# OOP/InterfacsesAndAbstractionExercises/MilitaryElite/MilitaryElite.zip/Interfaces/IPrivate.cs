﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Interfaces
{
    public interface IPrivate
    {

        double Salary { get; set; }

    }
}
