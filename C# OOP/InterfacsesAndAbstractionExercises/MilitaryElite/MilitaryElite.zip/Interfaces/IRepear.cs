﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Interfaces
{
    public interface IRepear
    {

        string PartName { get; set; }

        int HoursWorked { get; set; }

    }
}
