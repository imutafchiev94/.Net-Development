﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.HotelReservation
{
    public enum Season
    {
        Autumn,
        Spring,
        Winter,
        Summer
    }
}
