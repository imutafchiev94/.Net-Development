﻿namespace _02.LegionSystem.Models
{
    public class Kleer : Enemy
    {
        public Kleer(int attackSpeed, int health) 
            : base(attackSpeed, health)
        {
        }
    }
}
