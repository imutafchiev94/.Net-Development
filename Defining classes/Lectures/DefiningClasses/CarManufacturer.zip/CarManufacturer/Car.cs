﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    public class Car
    {


        private string make { get; set; }

        private string model { get; set; }

        private int year { get; set; }

        public string Make { get; set; }

        public string Model { get; set; }

        public int Year { get; set; }

    }
}
